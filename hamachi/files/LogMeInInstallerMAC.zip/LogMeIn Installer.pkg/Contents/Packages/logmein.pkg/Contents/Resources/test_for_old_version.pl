# http://jira/browse/LMIMAC-140
# This code is for working around a bug in Tiger Installer that causes the 
# wrong version to be installed if both versions are mounted with the same name

use FindBin;
use File::Basename;

my $path = $FindBin::Bin;

my $pkgdir = dirname(dirname($path));
my $relpkgpath = basename($pkgdir);
my $path = dirname($pkgdir);
my $name = basename($path);

my $infoplistrelpath = '/Contents/Info.plist';
my $pattern = '^LogMeIn Installer( \d+)?$';
my $pathpattern = '^/Volumes/LogMeIn Installer( \d+)?$';

my $volumesdir = '/Volumes';
my $origippath = $pkgdir.$infoplistrelpath;

if ($path =~ /$pathpattern/) {
	opendir(DIR, $volumesdir) || die "can't opendir $volumesdir: $!";
	    @items = grep { /$pattern/ } readdir(DIR);
	closedir DIR;
	
	for my $i (@items) {
		my $actippath = $volumesdir.'/'.$i.'/'.$relpkgpath.$infoplistrelpath;
		print("ERR:".$actippath);
		my @args = ("/usr/bin/cmp",$actippath,$origippath);
		system(@args) == 0
			 or die "system @args failed: $?";
		if (($? >> 8) == 1) {
			print "Found different versions of Info.plist at $actippath $origippath\n";
			exit(13);
		}
	}
}
exit(0);